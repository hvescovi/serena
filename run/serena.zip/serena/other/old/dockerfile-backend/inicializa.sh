#!/bin/sh
/usr/bin/python3 /backend.py
